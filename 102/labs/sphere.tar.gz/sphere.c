/* Elizabeth Stauder
2/08/15
Lab 1021-004
This file contains sphere function definitions for raytracer

sphere.c */

#include "ray.h"
#include <math.h>

void sphere_init(FILE  *in, model_t  *model, int  attrmax)
{
   sphere_t *sph;
   object_t *obj;
   int count;

	object_init(in, model);
 	
	obj = (object_t *)list_get_entity(model->objs);
   
	sph = (sphere_t*)malloc(sizeof(sphere_t));
  
 	obj->priv = sph;
	
   	strcpy(obj->obj_type, "sphere");


   count = sphere_load_attributes(in, sph, attrmax);
   assert(count == 2);

   	obj->hits = sphere_hits;
	obj->printer = sphere_print;

}
 
int sphere_load_attributes(FILE  *in, sphere_t  *sphere, int  attrmax)
{
  char attrib_name[16];
  int count = 0;     
  int attrcount = 0; 

  count = fscanf(in, "%s", attrib_name);
  assert(count == 1);

  while (attrib_name[0] != '}'){
 	if (strcmp(attrib_name, "center") == 0){
        count = fscanf(in, "%lf %lf %lf", &sphere->center.x, &sphere->center.y, &sphere->center.z);
	assert(count == 3);
	attrcount += 1;
 	}	

	else if (strcmp(attrib_name, "radius") == 0){
	count = fscanf(in, "%lf", &sphere->radius);
	assert(count == 1);
	attrcount += 1;
	}

	else {
	fprintf(stderr, "Bad camera attribute: %s \n", attrib_name);
	exit(1);
		}
	fscanf(in, "%s", attrib_name);
	}

return(attrcount);
}

void sphere_print(object_t  *obj,FILE  *out)
{
   sphere_t *sph;

   sph = obj->priv;
   
   object_print(obj, out);

   fprintf(out, "%-12s %3.1lf %3.1lf %3.1lf\n", "center", sph->center.x,
		sph->center.y, sph->center.z);
   fprintf(out, "%-12s %3.1lf\n", "radius", sph->radius); 
}



/************************************************************
 You do not have to implement this function during this lab.
         This will be implemented at a later time.
 ***********************************************************/

double sphere_hits(object_t  *obj, vec_t  *base, vec_t  *dir) 
{
	//sphere_t *sph;
	assert (obj->cookie == OBJ_COOKIE);

	// extract sph pointer from object structure 
	// see notes for sphere_hits function
   // --- CODE GOES HERE ---


	// return distance
	return -1;  // just for now

}
