/*
Elizabeth Stauder (estaude)
CPSC 1020-001
03/11/15
This part contains all the prototypes for the programs used in the project.
rayhdrs.h
*/
//CAMERA.C FUNCTIONS
void camera_init(FILE *in, model_t *model, int attrmax);
int camera_load_attributes(FILE *in, camera_t *cam);
void camera_getdir(camera_t *cam, int x, int y, vec_t *dir);
void camera_store_pixel(camera_t *cam, int x, int y, drgb_t *pix);
void scale_and_clamp(drgb_t *);
void camera_print(camera_t *cam, FILE *out);
void camera_write_image(camera_t *cam, FILE *out);
//LIST.C FUNCTIONS
list_t *list_init(void);
void list_add(list_t  *list, void  *entity);
void list_reset(list_t  *list);
int list_not_end(list_t  *list);
void list_next_link(list_t  *list);
void *list_get_entity(list_t  *list);
void list_del(list_t  *list);
//MATERIAL.C FUNCTIONS
void material_init(FILE *in, model_t *model, int attrmax);
void material_load_attributes(FILE *in, material_t *mat);
material_t *material_getbyname(model_t *model, char *name);
void material_print(material_t *mat, FILE *out);
void material_list_print(model_t *model, FILE *out);
void material_getambient(object_t *obj, material_t *mat, drgb_t *dest);
void material_getdiffuse(object_t *obj, material_t *mat, drgb_t *dest);
double material_getspecular(object_t *obj, material_t *mat);
//MODEL.C FUNCTIONS
model_t *model_init(FILE *in);
void model_load_entities(FILE *in, model_t *model);
void model_print(model_t *model, FILE *out);
//TPLANE.C FUNCTIONS
void tplane_init(FILE *in, model_t *model);
int tplane_load_attributes(FILE *in,tplane_t *tpln);
void tplane_print(object_t *obj, FILE *out);
void tplane_ambient(object_t *obj, material_t *mat, drgb_t *value);
int tplane_foreground(object_t *obj);
//PIXEL.C FUNCTIONS
void pix_scale(double s, drgb_t *p1, drgb_t *p2);
void pix_prod(drgb_t *p1, drgb_t *p2, drgb_t *p3);
void pix_sum(drgb_t *p1, drgb_t *p2, drgb_t *p3);
void pix_copy(drgb_t *p1, drgb_t *p2);
//PLANE.C FUNCTIONS
void plane_init(FILE  *in, model_t  *model, int  attrmax);
int plane_load_attributes(FILE  *in, plane_t  *pln, int  attrmax);
void plane_print(object_t  *obj, FILE  *out);
double  plane_hits(object_t  *obj, vec_t  *base, vec_t  *dir);
//SPHERE.C FUNCTIONS
void sphere_init(FILE  *in, model_t  *model, int  attrmax);
int sphere_load_attributes(FILE  *in, sphere_t  *sphere, int  attrmax);
void sphere_print(object_t  *obj,FILE  *out);
double sphere_hits(object_t  *obj, vec_t  *base, vec_t  *dir);
//IMAGE.C FUNCTIONS
void ray_trace (model_t *model, vec_t *base, vec_t *dir, drgb_t *pix, 
		double total_dist, object_t *last_hit);
void make_pixel(model_t  *model, int  x, int  y);
void make_row(model_t  *model, int  y);
void image_create(model_t  *model, FILE  *out);
//OBJECT.C FUNCTIONS
void  object_init(FILE  *in, model_t  *model);
void object_list_print(model_t  *model, FILE  *out);
void object_print(object_t *obj, FILE *out);
double object_no_hit(object_t  *obj, vec_t  *base, vec_t  *dir);
//FIND_CLOSEST_OBJECT FUNCTION
object_t *find_closest_object(model_t  *model, vec_t  *base, vec_t  *dir,
                              object_t  *last_hit, double  *retdist);
