/*
Elizabeth Stauder (estaude)
03/11/15 CPSC 1020-001
This program allocates memory for a plane structure,
parses, and loads the data for the structure.
tplane.c
*/
#include "ray.h"

void tplane_init(FILE *in, model_t *model)
{
   object_t *obj;
   tplane_t *tpln;
   plane_t *pln;
   //The 2 is passed to plane_init( ) to tell it not to 
   //process more than two attributes. 
   plane_init(in, model, 2);
   tpln = (tplane_t *)malloc(sizeof(tplane_t));
   obj = (void*)list_get_entity(model->objs);

   pln = obj->priv;

   tplane_load_attributes(in, tpln);
   pln->priv = tpln;

   obj->ambient = tplane_ambient;
   tpln->background = material_getbyname(model, tpln->matname);
   obj->printer = tplane_print;

   strcpy(obj->obj_type, "tiled_plane");
}

int tplane_load_attributes(FILE *in,tplane_t *tpln){
   char attrib_name[16];
   int count = 0;
   int attrcount = 0;
   count = fscanf(in, "%s", attrib_name);
   assert(count == 1);

   while (attrib_name[0] != '}'){
	if (strcmp(attrib_name, "dimension") == 0){
        	count = fscanf(in, "%lf %lf", 
			&tpln->dimension[0], &tpln->dimension[1]);
        	assert(count == 2);
		attrcount +=1;
        }

        else if (strcmp(attrib_name, "altmaterial") == 0){
        	fscanf(in, "%s", tpln->matname);
        	//assert(count == 1);
		attrcount +=1;
        }

        else {
       		fprintf(stderr, "Bad tplane attribute: %s \n", attrib_name);
        	exit(1);
                }
        fscanf(in, "%s", attrib_name);
	}
   return attrcount;
}

void tplane_print(object_t *obj, FILE *out)
{
   plane_print(obj, out);
   plane_t *pln = (plane_t *)obj->priv;
   tplane_t *tpln = (tplane_t *)pln->priv;
   //This part prints the tplane attributes.
   fprintf(out, "dimension %8.1lf %5.1lf\n", 
	tpln->dimension[0], tpln->dimension[1]);
   fprintf(out, "altmaterial %s\n", tpln->matname);
}

void tplane_ambient(object_t *obj, material_t *mat, drgb_t *value)
{
   plane_t *pln = (plane_t *)obj->priv;
   tplane_t *tpln = (tplane_t *)pln->priv;
   int foreground = tplane_foreground(obj);
   if(foreground){
	material_getambient(obj, obj->mat, value);}
   else{
	material_getambient(obj, tpln->background, value); }
}

int tplane_foreground(object_t *obj)
{
   plane_t *pln = (plane_t *)obj->priv;
   tplane_t *tpln = (tplane_t *)pln->priv;
   //A tile index is an int (x and z) plus 10000 and dividing by x or z.
   int x_ndx = (obj->last_hit.x + 10000) / tpln->dimension[0];
   int z_ndx = (obj->last_hit.z + 10000) / tpln->dimension[1];
   //This part determines if x_ndx + z_ndx is an even number.
   if((x_ndx + z_ndx) % 2 == 0){
	return(1);}
   else{
	return(0);}
}
