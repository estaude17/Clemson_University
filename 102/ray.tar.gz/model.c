/*
Elizabeth Stauder(estaude) 
CPSC 1020-001; 03/11/15
This program allocates memory for a model structure 
and loads data for the structure.
*/
#include "ray.h"

model_t *model_init(FILE *in){

   model_t *model = malloc(sizeof(model_t));
   assert(model != NULL);
   //This part initializes everything in model_t to 0.
   memset(model, 0, sizeof(model_t));
   //This part creates an empty list for mats, objs, and lgts lists.
   model->mats = list_init();
   assert(model->mats != NULL);

   model->lgts = list_init();
   assert(model->lgts != NULL);

   model->objs = list_init();
   assert(model->objs != NULL);

   model_load_entities(in, model);
   return model;
}

void model_load_entities(FILE *in, model_t *model){
   char entityname[NAME_LEN];
   int  count;

  // memset(entityname, 0, sizeof(entityname));

   count = fscanf(in, "%s", entityname);
   assert(count == 1);
   //This part loads all entity names and attributes for the different
   //parts of the program. The if/else decides which program to call.
   while (count == 1){
	if (strcmp(entityname, "camera") == 0){
		camera_init(in, model, 3);
		}
	else if (strcmp(entityname, "material") == 0){
		material_init(in, model, 0);
		}
	else if (strcmp(entityname, "plane") == 0){
		plane_init(in, model, 2);
		}
	else if (strcmp(entityname, "sphere") == 0){
		sphere_init(in, model, 2);
		}
        else if  (strcmp(entityname, "tiled_plane") == 0){
		tplane_init(in, model);
		}
/*	else {
          fprintf(stderr, "Bad entity: %s \n", entityname);
          exit(1);
                }*/
   count = fscanf(in, "%s", entityname);
    }
}

void model_print(model_t *model, FILE *out)
{
   //this part prints everything in the model by calling 3 print functions.
   camera_print(model->cam, out);
   material_list_print(model, out);
   object_list_print(model, out);
}
